//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    println("Enter a number to calculate the sum from 1 to that number:")
    val n = readLine()!!.toInt()

    // Using for loop to calculate sum
    var sumFor = 0
    for (i in 1..n) {
        sumFor += i
    }
    println("Sum using for loop: $sumFor")

    // Using while loop to calculate sum
    var sumWhile = 0
    var counter = 1
    while (counter <= n) {
        sumWhile += counter
        counter++
    }
    println("Sum using while loop: $sumWhile")
}
