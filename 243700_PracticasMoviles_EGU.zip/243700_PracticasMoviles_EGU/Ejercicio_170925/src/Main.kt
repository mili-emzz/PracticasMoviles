//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {


    print("Ingrese la cantidad de miligramos: ")
    var miligramos = readLine()!!.toInt()

    if(miligramos > 100){
        println("Felicidades es una buena pocion multijugos")
    }else println("La poción es mediocres, sangre inmunda")

}