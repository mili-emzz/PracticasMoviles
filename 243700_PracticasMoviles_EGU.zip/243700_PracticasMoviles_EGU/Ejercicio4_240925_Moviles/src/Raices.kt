import kotlin.math.sqrt
open class Raices(
    val a: Double,
    val b: Double,
    val c: Double
) {

    fun getDiscriminante(): Double {
        return (b * b) - (4 * a * c)
    }

    //mostrar posibles soluciones
    fun calcular() {
        if (tieneRaices()) { // Si el discriminante > 0
            obtenerRaices()
        } else if (tieneRaiz()) { // Si el discriminante == 0
            obtenerRaiz()
        } else { // Si el discriminante < 0
            println("La ecuación no tiene soluciones reales.")
        }
    }

    fun obtenerRaiz() {
        val discriminante = getDiscriminante()
        val raiz = (-b + sqrt(discriminante)) / (2 * a)
        println("La raiz 1 es: $raiz")
    }

    // retorno mas chido XD
    fun tieneRaices(): Boolean = getDiscriminante() > 0

    fun tieneRaiz(): Boolean = getDiscriminante() == 0.0

    fun obtenerRaices(){ // imprime dos posibles soluciones
        val discriminante = getDiscriminante()
        val raiz1 = (-b + sqrt(discriminante)) / (2 * a)
        val raiz2 = (-b - sqrt(discriminante)) / (2 * a)
        println("La raiz 1 es: $raiz1")
        println("La raiz 2 es: $raiz2")
    }
}