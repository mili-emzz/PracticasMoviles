//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
    val ecuacion1 = Raices(1.0, 5.0, 6.0)
    println("Ecuación con dos soluciones")
    ecuacion1.calcular()

    println("Ecuación con una solución")
    val ecuacion2 = Raices(1.0, 4.0, 4.0)
    ecuacion2.calcular()

    println("Ecuación sin soluciones")
    val ecuacion3 = Raices(1.0, 1.0, 1.0)
    ecuacion3.calcular()
}

