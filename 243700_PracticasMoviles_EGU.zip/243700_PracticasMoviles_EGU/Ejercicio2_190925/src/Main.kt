//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {

    var distance: Double
    var disponibility: Int
    var ready: Boolean
    var start: Boolean = true

        println("¿Cual es la distancia del conductor?")
        distance = readLine()!!.toDouble()

        println("¿Se encuentra disponible?\n 1. Si\n 0. No")
        disponibility = readLine()!!.toInt()

        when {
            distance <= 0.5 && disponibility == 1 -> print("Listo para iniciar recorrido")

            distance <= 0.5 && disponibility == 0 -> print("Conductor cercano pero no disponible")

            distance > 0.5 && disponibility == 1 -> print("Conductor listo pero muy lejos, se cobrará tarifa más alta")

            distance > 0.5 && disponibility == 0 -> print("No hay conductores disponibles")
            }

        }



