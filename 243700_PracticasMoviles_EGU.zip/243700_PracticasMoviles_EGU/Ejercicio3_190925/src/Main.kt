//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {

    var number: Int

    println("Que numero desea imprimir")
    number = readLine()!!.toInt()

    for (i in 1..number) {
        if (i % 2 == 0) {
            println("$i")
        }
    }

}