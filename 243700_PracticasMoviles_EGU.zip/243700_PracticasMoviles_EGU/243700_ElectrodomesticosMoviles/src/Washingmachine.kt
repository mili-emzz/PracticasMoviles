
class Washingmachine(
    // Parámetros del constructor primario, que se pasan a la superclase
    basePrice: Double,
    color: String,
    energyConsume: Char,
    weight: Double,
    // Atributo propio, con su valor por defecto
    var load: Double = LOAD
) : Electrodomestic(basePrice, color, energyConsume, weight) { // Llama al constructor de la superclase con los parámetros

    companion object{
        const val LOAD = 5.0
    }

    constructor(basePrice: Double,weight: Double): this(
        basePrice = basePrice,
        color = COLOR,
        energyConsume = ENERGY_CONSUME,
        weight = weight,
        load = LOAD
    )

    constructor(): this(
        load = LOAD,
        basePrice = BASE_PRICE,
        weight = WEIGHT,
        energyConsume = ENERGY_CONSUME,
        color = COLOR
    )


    override fun finalPrice(): Double {
        var finalPrice = super.finalPrice()

        if (load > 30){
            finalPrice+=50.0
        }
        return finalPrice
    }

}