//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
fun main() {
   val electrodomestics: Array<Electrodomestic?> = arrayOfNulls(10)

    electrodomestics[0] = Washingmachine(9000.0,"BLANCO",'A',90.0,10.0)
    electrodomestics[2] = Electrodomestic(100.0, "ROJO", 'B',30.00 )
    electrodomestics[3] = Washingmachine(900.0,"NEGRO",'C',90.0,40.0)
    electrodomestics[4] = TV(1000.0,"AZUL", 'D',120.0, 20.0, true)
    electrodomestics[5] = TV(1100.0,"GRIS", 'D',12.0, 45.0, false)

    var totalElectrodomestic: Double = 0.0
    var totalWashingmachine: Double = 0.0
    var totalTV: Double = 0.0

    for(e in electrodomestics) {
        var price = e.finalPrice()
        totalElectrodomestic += price

        if(e is Washingmachine) {
            totalWashingmachine += price
     } else if (e is TV) {
         totalTV += price
     }
    }



}