import java.sql.Struct

open class Electrodomestic(
    open var basePrice: Double = BASE_PRICE,
    open var color: String = COLOR,
    open var energyConsume: Char = ENERGY_CONSUME,
    open var weight: Double = WEIGHT
) {

    companion object {
        const val BASE_PRICE = 100.0
        const val COLOR = "blanco"
        const val ENERGY_CONSUME = 'F'
        const val WEIGHT = 5.0
    }

    constructor(basePrice: Double, witdh: Double) : this(basePrice, COLOR, ENERGY_CONSUME, witdh)

    constructor():this(
        basePrice = BASE_PRICE,
        weight =  WEIGHT
    )

    init {
        color=checkColor()
        energyConsume=checkEnergyConsumption(energyConsume)
    }

    //Metodos
    fun checkEnergyConsumption(letter: Char): Char {
        return if (letter in 'A'..'F') letter else ENERGY_CONSUME
    }

    fun checkColor(): String {
        val dispColors=setOf("BLANCO","NEGRO","ROJO","AZUL","GRIS")
        return if (color in dispColors) color else "BLANCO"
    }

    // precioFinal con las reglas comunes (valores habituales del ejercicio)
    open fun finalPrice():Double{
        var finalPrice=basePrice

        // Incremento por consumo energético
        finalPrice+=when(energyConsume){
            'A'->100.0
            'B'->80.0
            'C'->60.0
            'D'->50.0
            'E'->30.0
            'F'->10.0
            else->0.0
        }

        // Incremento por peso
        finalPrice+=when{
            weight<20->10.0
            weight<50->50.0
            weight<80->80.0
            else->100.0
        }

        return finalPrice
    }
}