class TV (
    basePrice: Double,
    color: String,
    energyConsume: Char,
    weight: Double,
    var resolution: Double = RESOLUTION,
    var tuner: Boolean = TUNER): Electrodomestic(basePrice, color, energyConsume, weight) {

        companion object {
            const val RESOLUTION: Double = 20.00
            const val TUNER: Boolean = false
        }


    constructor(basePrice: Double, weight: Double): this(
        basePrice = basePrice,
        color = COLOR,
        energyConsume = ENERGY_CONSUME,
        weight = weight
    )

    constructor(): this(
        basePrice = BASE_PRICE,
        color = COLOR,
        energyConsume = ENERGY_CONSUME,
        weight = WEIGHT
    )

    override fun finalPrice(): Double {
        var price = super.finalPrice()

        // Si la resolución es mayor de 40 pulgadas, se incrementa el precio un 30%
        if (resolution > 40) {
            price += (price * 1.30)
        }
        // Si tiene un sintonizador TDT incorporado, aumenta 50 € [cite: 45]
        if (tuner){
            price += 50.0
        }

        return price
    }




}
